const NotFound = () => {
  return <div className="text-center mt-10 text-2xl">404 Page Not Found</div>;
};

export default NotFound;