import React from "react";
import "./Home.css";

const categories = [
  "All",
  "Music",
  "Sports",
  "Technology",
  "Arts",
  "Food",
  "Business",
];

const Home = () => {
  return (
    <div className="home">
      {/* Navbar */}
      <nav className="navbar">
        <div className="logo">⚡ EventScale</div>
        <div className="nav-links">
          <a href="#">Calendar</a>
          <a href="#">Login</a>
          <button className="signup-btn">Sign Up</button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero">
        <h1>Discover Amazing Events</h1>
        <p>Book tickets to concerts, sports, conferences, and more</p>

        <div className="search-box">
          <input
            type="text"
            placeholder="Search events by name, location..."
          />
        </div>

        <div className="categories">
          {categories.map((cat, index) => (
            <button
              key={index}
              className={`category-btn ${index === 0 ? "active" : ""}`}
            >
              {cat}
            </button>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;