const Footer = () => {
  return (
    <footer className="bg-black text-white text-center p-4 mt-10">
      © 2026 EventBook. All Rights Reserved.
    </footer>
  );
};

export default Footer;